package com.pretzero.fitsure.model.service;

import org.springframework.stereotype.Service;

@Service
public class NoticeServiceImpl implements NoticeService {

}
