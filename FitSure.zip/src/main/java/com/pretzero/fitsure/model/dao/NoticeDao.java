package com.pretzero.fitsure.model.dao;

public interface NoticeDao {

}
