package com.pretzero.fitsure.model.service;

public interface CouponService {

}
